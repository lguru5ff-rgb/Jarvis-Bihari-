package com.example.jarvisbihari;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView output;
    private EditText input;
    private TextToSpeech tts;
    private static final int REQ_SPEECH = 101;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUI();
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi","IN"));
        });
    }

    private void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28,40,28,24);
        root.setBackgroundColor(Color.rgb(5,7,10));

        TextView title = new TextView(this);
        title.setText("JARVIS");
        title.setTextColor(Color.CYAN);
        title.setTextSize(32);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1,80));

        output = new TextView(this);
        output.setText("नमस्ते! मैं JARVIS हूँ।\nबोलिए या नीचे command लिखिए।");
        output.setTextColor(Color.WHITE);
        output.setTextSize(18);
        output.setGravity(Gravity.CENTER);
        root.addView(output, new LinearLayout.LayoutParams(-1,0,1));

        input = new EditText(this);
        input.setHint("Command लिखें...");
        input.setSingleLine(true);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.GRAY);
        root.addView(input, new LinearLayout.LayoutParams(-1,60));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        Button mic = new Button(this); mic.setText("🎤 बोलें");
        Button send = new Button(this); send.setText("Send");
        row.addView(mic, new LinearLayout.LayoutParams(0,70,1));
        row.addView(send, new LinearLayout.LayoutParams(0,70,1));
        root.addView(row);

        mic.setOnClickListener(v -> startVoice());
        send.setOnClickListener(v -> handle(input.getText().toString()));

        setContentView(root);
    }

    private void startVoice() {
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_SPEECH);
            return;
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए...");
        try { startActivityForResult(i, REQ_SPEECH); }
        catch (Exception e) { speak("Voice recognition उपलब्ध नहीं है।"); }
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r,c,d);
        if (r == REQ_SPEECH && c == RESULT_OK && d != null) {
            ArrayList<String> a = d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (a != null && !a.isEmpty()) handle(a.get(0));
        }
    }

    private void handle(String cmd) {
        if (cmd == null) return;
        String s = cmd.toLowerCase(Locale.ROOT).trim();
        String reply;
        if (s.contains("hello") || s.contains("हेलो") || s.contains("नमस्ते")) {
            reply = "नमस्ते! बताइए, का मदद करीं?";
        } else if (s.contains("समय") || s.contains("time")) {
            reply = "अभी समय है " + new java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new java.util.Date());
        } else if (s.contains("youtube")) {
            reply = "YouTube खोल रहा हूँ।";
            open("https://www.youtube.com");
        } else if (s.contains("google") || s.contains("सर्च") || s.contains("search")) {
            reply = "Google search खोल रहा हूँ।";
            open("https://www.google.com");
        } else if (s.contains("बंद") || s.contains("stop")) {
            reply = "ठीक बा, अभी रुकतानी।";
        } else {
            reply = "आपने कहा: " + cmd + ". अभी ई command basic mode में है।";
        }
        output.setText("JARVIS: " + reply);
        speak(reply);
    }

    private void open(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception ignored) {}
    }

    private void speak(String text) {
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis");
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
